const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { Chess } = require('chess.js');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
const PORT = process.env.PORT || 4000;

const TIME_PRESETS = {
  '1m': { initial: 60, increment: 0 },
  '3m': { initial: 180, increment: 0 },
  '3m+2s': { initial: 180, increment: 2 },
  '10m': { initial: 600, increment: 0 },
  '10m+5s': { initial: 600, increment: 5 }
};

const rooms = new Map();

function createRoom(roomId, creatorSocketId, timeKey = '3m') {
  const chess = new Chess();
  const preset = TIME_PRESETS[timeKey] || TIME_PRESETS['3m'];
  rooms.set(roomId, {
    chess,
    players: [creatorSocketId],
    watchers: [],
    timeKey,
    clocks: { w: preset.initial, b: preset.initial },
    increment: preset.increment,
    turnStart: Date.now()
  });
}

function updateClocks(room) {
  const now = Date.now();
  const elapsed = (now - room.turnStart) / 1000;
  const turn = room.chess.turn();
  room.clocks[turn] -= elapsed;
  if (room.clocks[turn] < 0) room.clocks[turn] = 0;
  room.turnStart = now;
}

io.on('connection', (socket) => {
  console.log('connected', socket.id);

  socket.on('create-room', (roomId, timeKey, cb) => {
    if (rooms.has(roomId)) return cb({ ok: false, error: 'Room already exists' });
    createRoom(roomId, socket.id, timeKey);
    socket.join(roomId);
    cb({ ok: true, roomId, fen: rooms.get(roomId).chess.fen(), clocks: rooms.get(roomId).clocks });
  });

  socket.on('join-room', (roomId, cb) => {
    const room = rooms.get(roomId);
    if (!room) return cb({ ok: false, error: 'No such room' });

    if (room.players.length < 2 && !room.players.includes(socket.id)) {
      room.players.push(socket.id);
    } else {
      room.watchers.push(socket.id);
    }
    socket.join(roomId);
    const color =
      room.players[0] === socket.id
        ? 'white'
        : room.players[1] === socket.id
        ? 'black'
        : 'watch';
    cb({ ok: true, fen: room.chess.fen(), color, clocks: room.clocks });
  });

  socket.on('make-move', ({ roomId, from, to, promotion }, cb) => {
    const room = rooms.get(roomId);
    if (!room) return cb({ ok: false, error: 'No such room' });

    updateClocks(room);
    const playerIndex = room.players.indexOf(socket.id);
    const side = playerIndex === 0 ? 'w' : playerIndex === 1 ? 'b' : null;
    if (!side) return cb({ ok: false, error: 'Spectator' });
    if (room.chess.turn() !== side) return cb({ ok: false, error: 'Not your turn' });
    if (room.clocks[side] <= 0) return cb({ ok: false, error: 'Time out' });

    const move = room.chess.move({ from, to, promotion });
    if (!move) return cb({ ok: false, error: 'Illegal move' });

    room.clocks[side] += room.increment;
    room.turnStart = Date.now();

    io.to(roomId).emit('move-made', { fen: room.chess.fen(), move, clocks: room.clocks });
    cb({ ok: true, fen: room.chess.fen(), clocks: room.clocks });
  });
});

app.use(express.static(path.join(__dirname, 'client', 'dist')));
server.listen(PORT, () => console.log('Server running on port', PORT));