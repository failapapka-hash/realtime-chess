import React, { useState, useEffect } from 'react'
import { io } from 'socket.io-client'
import { Chess } from 'chess.js'
import ChessBoard from './ChessBoard'

const socket = io('http://localhost:4000')
const TIME_PRESETS = ['1m', '3m', '3m+2s', '10m', '10m+5s']

export default function App() {
  const [roomId, setRoomId] = useState('room-' + Math.random().toString(36).slice(2, 6))
  const [fen, setFen] = useState(new Chess().fen())
  const [color, setColor] = useState('watch')
  const [clocks, setClocks] = useState({ w: 180, b: 180 })
  const [timeKey, setTimeKey] = useState('3m')

  useEffect(() => {
    socket.on('move-made', (data) => {
      setFen(data.fen)
      if (data.clocks) setClocks(data.clocks)
    })
  }, [])

  const createRoom = () => {
    socket.emit('create-room', roomId, timeKey, (res) => {
      if (res.ok) {
        setFen(res.fen)
        setColor('white')
        setClocks(res.clocks)
      } else alert(res.error)
    })
  }

  const joinRoom = () => {
    socket.emit('join-room', roomId, (res) => {
      if (res.ok) {
        setFen(res.fen)
        setColor(res.color)
        setClocks(res.clocks)
      } else alert(res.error)
    })
  }

  const makeMove = (from, to) => {
    socket.emit('make-move', { roomId, from, to }, (res) => {
      if (res.ok) setFen(res.fen)
    })
  }

  return (
    <div className="app">
      <header>
        <h1>Realtime Chess</h1>
      </header>
      <main>
        <aside className="panel">
          <label>Room ID</label>
          <input value={roomId} onChange={(e) => setRoomId(e.target.value)} />
          <label>Time Control</label>
          <select value={timeKey} onChange={(e) => setTimeKey(e.target.value)}>
            {TIME_PRESETS.map((k) => (
              <option key={k}>{k}</option>
            ))}
          </select>
          <div className="buttons">
            <button onClick={createRoom}>Create</button>
            <button onClick={joinRoom}>Join</button>
          </div>
          <div>White: {Math.floor(clocks.w / 60)}:{('0' + Math.floor(clocks.w % 60)).slice(-2)}</div>
          <div>Black: {Math.floor(clocks.b / 60)}:{('0' + Math.floor(clocks.b % 60)).slice(-2)}</div>
          <div>Your color: {color}</div>
        </aside>

        <section>
          <ChessBoard fen={fen} onMove={makeMove} perspective={color} selectable={color !== 'watch'} />
        </section>
      </main>
    </div>
  )
}