import React, { useMemo, useState } from 'react'
import { Chess } from 'chess.js'

const unicode = {
  p: '♟', r: '♜', n: '♞', b: '♝', q: '♛', k: '♚',
  P: '♙', R: '♖', N: '♘', B: '♗', Q: '♕', K: '♔'
}

export default function ChessBoard({ fen, onMove, perspective = 'white', selectable = true }) {
  const chess = useMemo(() => new Chess(fen), [fen])
  const [selected, setSelected] = useState(null)

  const ranks = perspective === 'black' ? [1,2,3,4,5,6,7,8] : [8,7,6,5,4,3,2,1]
  const files = perspective === 'black' ? ['h','g','f','e','d','c','b','a'] : ['a','b','c','d','e','f','g','h']

  const board = chess.board()

  const clickSquare = (file, rank) => {
    const coord = `${file}${rank}`
    if (selected) {
      onMove(selected, coord)
      setSelected(null)
    } else if (selectable) {
      setSelected(coord)
    }
  }

  return (
    <div className="board">
      {ranks.map(rank => (
        <div key={rank} className="rank">
          {files.map(file => {
            const piece = board[8 - rank][files.indexOf(file)]
            const squareColor = (files.indexOf(file) + rank) % 2 === 0 ? 'light' : 'dark'
            return (
              <div key={file+rank} className={`square ${squareColor} ${selected === `${file}${rank}` ? 'selected' : ''}`} onClick={() => clickSquare(file, rank)}>
                {piece && <span className="piece">{unicode[piece.color === 'w' ? piece.type.toUpperCase() : piece.type]}</span>}
              </div>
            )
          })}
        </div>
      ))}
    </div>
  )
}